//
// Created by shiri on 08/06/2022.
//



#include "Battle.h"

Battle::Battle(CardType type) :Card(type) {}


